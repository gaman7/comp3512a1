<?php
// Define the path to the database file
$databasePath = 'data/music.db';
        //include('H&S/header.php'); // Include the common header
        //require("db.php"); // include database 
        //$databasePath = 'data/music.db';
    
        $servername = "localhost";
        $username= "root";
        $password= "";
        $dbname="music";
        //$port = "3306";
        
        //create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
                if (!$conn) {
           die("Sorry we failed to connect".mysqli_connect_error());
        }
        else{
        echo "connection was successful <br>";
        }
        $sql= "SELECT * From 'artists'";
        $result = mysqli_query($conn,$sql);

        //no. of records
        $num = mysqli_num_rows($result);
        echo $num; 
        echo "<br>";

        ?>



