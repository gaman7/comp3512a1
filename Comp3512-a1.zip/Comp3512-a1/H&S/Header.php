<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>COMP 3512 Assign1</title>
    <link rel="stylesheet" type="text/css" href="./Css/styles.css">
</head>
<body>
    <header>
        <h1>COMP 3512 Assign1</h1>
        <h2>Gaman Kaur</h2>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                
                <li><a href="search.php">Search</a></li>
                <li><a href="view_favorites.php">Favorites</a></li>
                <li><a href="about.php">About Us</a></li>
            </ul>
        </nav>
    </header>
