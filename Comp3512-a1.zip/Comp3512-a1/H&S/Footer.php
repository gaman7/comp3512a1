<footer>
<link rel="stylesheet" type="text/css" href="./Css/styles.css">
    <p>Course Name: COMP 3512</p>
    <p>Copyright &copy; <?php echo date('Y'); ?> Gaman Kaur</p>
    <p>GitHub Repository: <a href="https://github.com/your-repo-link">Github  Repo</a></p>
    <p>GitHub Profile:
        <a href="#">Gamanv7</a>
        
    </p>
</footer>
</body>
</html>
